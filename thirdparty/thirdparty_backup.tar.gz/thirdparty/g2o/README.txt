You should have received this g2o version along with ORB-SLAM (https://github.com/raulmur/ORB_SLAM).
See the original g2o library at: https://github.com/RainerKuemmerle/g2o
All files included in this g2o version are BSD, see license-bsd.txt
