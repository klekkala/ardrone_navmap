#ifndef __YC_H
#define __YC_H

namespace CVD {

  struct YC {
    unsigned char y; // luminance
    unsigned char c; // U or V
  };
}






#endif
